# Proof — Progress & Wins Tracker

A personal achievement, habit, and progress tracker. Built to answer one question on the hard days: *did I actually do anything?*

Not a mental-health diagnostic tool — just proof, in your own logged data, that you're moving.

## Deploy to GitHub Pages

1. Create a new repo (e.g. `Proof`) and upload all files in this folder to it (`index.html`, `app.js`, `manifest.json`, `sw.js`, icons).
2. Go to **Settings → Pages** in the repo.
3. Under **Source**, choose the `main` branch and `/ (root)` folder, then Save.
4. Your app will be live at `https://<your-username>.github.io/Proof/`.
5. Open that link on your phone and use **Share → Add to Home Screen** (iOS) or the install prompt (Android/Chrome) to install it like a native app.

## Notes

- All data is stored locally on your device (`localStorage`) — nothing is sent anywhere.
- Use **Settings → Export** regularly to back up your data as JSON, especially before clearing browser data.
- First launch seeds a few sample entries so you can see how it works — use **Settings → Reset** for a clean slate.
